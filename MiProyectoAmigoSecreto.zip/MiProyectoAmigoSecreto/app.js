class AmigoSecreto {
    constructor() {
        this.amigos = [];
        this.listaAmigos = document.getElementById("listaAmigos");
        this.resultado = document.getElementById("resultado");
    }

    // Agregar un amigo a la lista
    agregarAmigo() {
        let nombre = document.getElementById("nombre").value.trim();

        if (nombre === "") {
            alert("⚠️ Ingresa un nombre válido.");
            return;
        }

        if (this.amigos.includes(nombre)) {
            alert("❌ Ese nombre ya está en la lista.");
            return;
        }

        this.amigos.push(nombre);
        this.actualizarLista();
        document.getElementById("nombre").value = "";
    }

    // Actualizar la lista en pantalla
    actualizarLista() {
        this.listaAmigos.innerHTML = "";

        if (this.amigos.length === 0) {
            this.listaAmigos.innerHTML = "<li>No hay participantes aún.</li>";
            return;
        }

        this.amigos.forEach((amigo, index) => {
            let li = document.createElement("li");
            li.innerHTML = `${amigo} <button onclick="juego.eliminarAmigo(${index})">❌</button>`;
            this.listaAmigos.appendChild(li);
        });
    }

    // Eliminar un amigo de la lista
    eliminarAmigo(index) {
        this.amigos.splice(index, 1);
        this.actualizarLista();
    }

    // Sorteo de un solo amigo secreto aleatorio
    sortearAmigo() {
        if (this.amigos.length < 2) {
            alert("⚠️ Debe haber al menos 2 participantes.");
            return;
        }

        let indiceAleatorio = Math.floor(Math.random() * this.amigos.length);
        let amigoSecreto = this.amigos[indiceAleatorio];

        // Mostrar solo un nombre en pantalla
        this.resultado.innerHTML = `<p>🎁 Tu amigo secreto es: <strong>${amigoSecreto}</strong></p>`;
    }

    // Vaciar la lista
    vaciarLista() {
        this.amigos = [];
        this.resultado.innerHTML = "...";
        this.actualizarLista();
    }
}

// Inicializar el juego
const juego = new AmigoSecreto();
